#include <lib.h>

int main() {
	while (1) {
		debugf("IDLE!");
	}
	return 0;
}
