#ifndef _CONSOLE_H_
#define _CONSOLE_H_

void printcharc(char ch);
int scancharc(void);
void halt(void);

#endif
